"""
Scoring Module
Aggregates findings from all analysis modules and computes a risk score (0–100).
"""


# Weight table: maps finding types to point values
SCORE_TABLE = {
    # Header findings
    'FROM_REPLY_TO_MISMATCH':       15,
    'FROM_RETURN_PATH_MISMATCH':    10,
    'DISPLAY_NAME_SPOOFING':        30,
    'SPF_FAIL':                     26,
    'DKIM_FAIL':                    26,
    'DMARC_FAIL':                   26,
    'SUSPICIOUS_MAILER':            20,
    'URGENCY_KEYWORDS':             10,
    'EXCESSIVE_HOPS':               10,

    # Domain findings
    'NO_DOMAIN':                    25,
    'DNS_NO_RESOLVE':               35,
    'NEW_DOMAIN':                   26,
    'YOUNG_DOMAIN':                 15,
    'TYPOSQUAT':                    40,

    # URL findings
    'IP_URL':                       50,
    'URL_SHORTENER':                15,
    'SUSPICIOUS_TLD':               30,
    'DECEPTIVE_SUBDOMAIN':          50,
    'EXCESSIVE_REDIRECTS':          15,
    'PHISHING_URL_KEYWORDS':        10,

    # Attachment findings
    'EXECUTABLE_ATTACHMENT':        80,
    'ARCHIVE_ATTACHMENT':           10,
    'PDF_SUSPICIOUS':               75,
    'MACRO_DETECTED':               50,
    'VBA_SUSPICIOUS':               40,
    'TOOL_ERROR':                   0,
}


def calculate_score(header_results, domain_results, url_results, attachment_results):
    """
    Calculate a risk score from 0 to 100.

    Collects all findings from every module, applies weights,
    and returns the total score (capped at 100) with a breakdown.

    Returns:
        dict with keys: score, max_score, breakdown, findings_count
    """
    all_findings = []
    breakdown = []

    # Gather findings from each module
    for module_name, results in [
        ('Header Analysis', header_results),
        ('Domain Analysis', domain_results),
        ('URL Analysis', url_results),
        ('Attachment Analysis', attachment_results),
    ]:
        findings = results.get('findings', [])
        module_points = 0
        module_items = []

        for finding in findings:
            ftype = finding.get('type', '')
            points = SCORE_TABLE.get(ftype, 5)  # Default 5 for unknown types
            module_points += points
            module_items.append({
                'type': ftype,
                'title': finding.get('title', ''),
                'severity': finding.get('severity', 'low'),
                'points': points,
            })
            all_findings.append(finding)

        breakdown.append({
            'module': module_name,
            'points': module_points,
            'items': module_items,
            'count': len(findings),
        })

    # -------------------------------------------------------------------------
    # Heuristic Combo Multipliers
    # -------------------------------------------------------------------------
    finding_types = {f.get('type') for f in all_findings}
    combo_penalties = 0
    combo_items = []

    def add_combo(name, points, reason):
        nonlocal combo_penalties
        combo_penalties += points
        combo_items.append({
            'type': 'COMBO_PENALTY',
            'title': name,
            'severity': 'high',
            'points': points,
            'explanation': reason
        })

    # 1. Urgent Short Link
    if 'URGENCY_KEYWORDS' in finding_types and 'URL_SHORTENER' in finding_types:
        add_combo('Urgent Short Link', 20, 'Urgent language combined with a hidden URL destination is a classic phishing tactic.')

    # 2. Spoofed Sender + Short Link
    if ('SPF_FAIL' in finding_types or 'DKIM_FAIL' in finding_types or 'DMARC_FAIL' in finding_types) and 'URL_SHORTENER' in finding_types:
        add_combo('Spoofed Sender + Short Link', 15, 'Sender failed authentication and uses a shortened URL to hide the destination.')

    # 3. Urgent Suspicious Link
    if 'URGENCY_KEYWORDS' in finding_types and 'SUSPICIOUS_TLD' in finding_types:
        add_combo('Urgent Suspicious Link', 15, 'Urgent language combined with a low-reputation top-level domain.')

    # 4. Mismatched New Domain
    if 'FROM_REPLY_TO_MISMATCH' in finding_types and 'NEW_DOMAIN' in finding_types:
        add_combo('Mismatched New Domain', 15, 'A newly registered domain combined with a mismatched reply-to address.')

    # 5. Spoofed New Domain
    if ('SPF_FAIL' in finding_types or 'DKIM_FAIL' in finding_types or 'DMARC_FAIL' in finding_types) and 'NEW_DOMAIN' in finding_types:
        add_combo('Spoofed New Domain', 15, 'A newly registered domain that also fails sender authentication.')

    # 6. Urgent Archive
    if 'URGENCY_KEYWORDS' in finding_types and 'ARCHIVE_ATTACHMENT' in finding_types:
        add_combo('Urgent Archive', 15, 'Urgent language used to pressure the user into opening an archive file.')

    # 7. Spoofed Sender + Malware Attachment
    if ('SPF_FAIL' in finding_types or 'DKIM_FAIL' in finding_types) and ('EXECUTABLE_ATTACHMENT' in finding_types or 'MACRO_DETECTED' in finding_types or 'VBA_SUSPICIOUS' in finding_types):
        add_combo('Spoofed Sender + Malicious Attachment', 30, 'Authentication failure combined with a potentially malicious document/executable.')

    # 8. Mismatched Reply-To + Suspicious URL
    if 'FROM_REPLY_TO_MISMATCH' in finding_types and ('SUSPICIOUS_TLD' in finding_types or 'IP_URL' in finding_types or 'DECEPTIVE_SUBDOMAIN' in finding_types or 'PHISHING_URL_KEYWORDS' in finding_types):
        add_combo('Mismatched Sender + Suspicious Link', 25, 'Reply-to mismatch coupled with a deceptive or IP-based destination.')

    # 9. No Domain + Suspicious URLs
    if 'NO_DOMAIN' in finding_types and ('DECEPTIVE_SUBDOMAIN' in finding_types or 'IP_URL' in finding_types or 'PHISHING_URL_KEYWORDS' in finding_types):
        add_combo('No Domain Info + Deceptive Link', 20, 'Missing sender domain information combined with a highly suspicious URL.')

    # 10. Urgency + Spoofed Sender
    if 'URGENCY_KEYWORDS' in finding_types and ('SPF_FAIL' in finding_types or 'DKIM_FAIL' in finding_types):
        add_combo('Urgent Sender Spoofing', 15, 'Urgent language combined with SPF/DKIM verification failure.')

    # 11. Malicious Payload Baseline (Guarantees Quarantine/Block)
    malicious_url = {'IP_URL', 'DECEPTIVE_SUBDOMAIN', 'PHISHING_URL_KEYWORDS'}
    malicious_attachment = {'EXECUTABLE_ATTACHMENT', 'MACRO_DETECTED', 'VBA_SUSPICIOUS', 'PDF_SUSPICIOUS'}
    if finding_types.intersection(malicious_url) or finding_types.intersection(malicious_attachment):
        add_combo('Malicious Payload Minimum', 25, 'The presence of a highly dangerous URL or attachment establishes a baseline high risk score.')

    if combo_items:
        breakdown.append({
            'module': 'Heuristic Combos',
            'points': combo_penalties,
            'items': combo_items,
            'count': len(combo_items),
        })

    raw_score = sum(b['points'] for b in breakdown)
    capped_score = min(raw_score, 100)

    return {
        'score': capped_score,
        'raw_score': raw_score,
        'breakdown': breakdown,
        'findings_count': len(all_findings),
    }
