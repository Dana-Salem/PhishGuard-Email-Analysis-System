"""
Email Parser Module
Parses .eml files and extracts sender, subject, body, URLs, and attachments.
"""

import email
import email.policy
import re
import os
import tempfile
from email import message_from_bytes
from email.utils import parseaddr
from html.parser import HTMLParser


class HTMLTextExtractor(HTMLParser):
    """Strips HTML tags and extracts plain text."""

    def __init__(self):
        super().__init__()
        self.result = []
        self._skip = False

    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style'):
            self._skip = True

    def handle_endtag(self, tag):
        if tag in ('script', 'style'):
            self._skip = False

    def handle_data(self, data):
        if not self._skip:
            self.result.append(data)

    def get_text(self):
        return ' '.join(self.result)


class HTMLLinkExtractor(HTMLParser):
    """Extracts all href URLs from HTML content."""

    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag == 'a':
            for attr_name, attr_value in attrs:
                if attr_name == 'href' and attr_value:
                    self.links.append(attr_value)


def extract_urls_from_text(text):
    """Extract URLs from plain text using regex."""
    url_pattern = re.compile(
        r'https?://[^\s<>"\')\]}>]+',
        re.IGNORECASE
    )
    return list(set(url_pattern.findall(text)))


def extract_urls_from_html(html_content):
    """Extract URLs from HTML href attributes and text content."""
    urls = set()

    # Extract from href attributes
    link_extractor = HTMLLinkExtractor()
    try:
        link_extractor.feed(html_content)
        for link in link_extractor.links:
            if link.startswith(('http://', 'https://')):
                urls.add(link)
    except Exception:
        pass

    # Also extract URLs from raw HTML text
    urls.update(extract_urls_from_text(html_content))

    return list(urls)


def parse_email(eml_path):
    """
    Parse a .eml file and return structured data.

    Args:
        eml_path: Path to the .eml file

    Returns:
        dict with keys: headers, body_text, body_html, urls, attachments
    """
    with open(eml_path, 'rb') as f:
        msg = message_from_bytes(f.read(), policy=email.policy.default)

    # --- Extract Headers ---
    from_header = msg.get('From', '')
    from_name, from_email = parseaddr(from_header)

    reply_to_header = msg.get('Reply-To', '')
    reply_to_name, reply_to_email = parseaddr(reply_to_header)

    return_path_header = msg.get('Return-Path', '')
    _, return_path_email = parseaddr(return_path_header)

    received_headers = msg.get_all('Received', [])
    auth_results = msg.get('Authentication-Results', '')
    x_mailer = msg.get('X-Mailer', '')
    message_id = msg.get('Message-ID', '')

    headers = {
        'from_raw': from_header,
        'from_name': from_name,
        'from_email': from_email.lower() if from_email else '',
        'to': msg.get('To', ''),
        'subject': msg.get('Subject', '(No Subject)'),
        'date': msg.get('Date', ''),
        'reply_to_raw': reply_to_header,
        'reply_to_email': reply_to_email.lower() if reply_to_email else '',
        'return_path_raw': return_path_header,
        'return_path_email': return_path_email.lower() if return_path_email else '',
        'received': received_headers,
        'authentication_results': auth_results,
        'x_mailer': x_mailer,
        'message_id': message_id,
    }

    # --- Extract Body ---
    body_text = ''
    body_html = ''

    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            content_disposition = str(part.get('Content-Disposition', ''))

            # Skip attachments
            if 'attachment' in content_disposition:
                continue

            if content_type == 'text/plain':
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or 'utf-8'
                    try:
                        body_text += payload.decode(charset, errors='replace')
                    except Exception:
                        body_text += payload.decode('utf-8', errors='replace')

            elif content_type == 'text/html':
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or 'utf-8'
                    try:
                        body_html += payload.decode(charset, errors='replace')
                    except Exception:
                        body_html += payload.decode('utf-8', errors='replace')
    else:
        content_type = msg.get_content_type()
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or 'utf-8'
            try:
                decoded = payload.decode(charset, errors='replace')
            except Exception:
                decoded = payload.decode('utf-8', errors='replace')

            if content_type == 'text/html':
                body_html = decoded
            else:
                body_text = decoded

    # If we only have HTML, extract text from it
    if not body_text and body_html:
        extractor = HTMLTextExtractor()
        try:
            extractor.feed(body_html)
            body_text = extractor.get_text()
        except Exception:
            body_text = ''

    # --- Extract URLs ---
    urls = set()
    if body_text:
        urls.update(extract_urls_from_text(body_text))
    if body_html:
        urls.update(extract_urls_from_html(body_html))
    urls = list(urls)

    # --- Extract Attachments ---
    attachments = []
    temp_dir = tempfile.mkdtemp(prefix='phish_analyzer_')

    if msg.is_multipart():
        for part in msg.walk():
            content_disposition = str(part.get('Content-Disposition', ''))
            filename = part.get_filename()

            if filename or 'attachment' in content_disposition:
                if not filename:
                    ext = part.get_content_type().split('/')[-1]
                    filename = f'attachment.{ext}'

                # Sanitize filename
                filename = os.path.basename(filename)
                filepath = os.path.join(temp_dir, filename)

                payload = part.get_payload(decode=True)
                if payload:
                    with open(filepath, 'wb') as f:
                        f.write(payload)

                    attachments.append({
                        'filename': filename,
                        'filepath': filepath,
                        'content_type': part.get_content_type(),
                        'size': len(payload),
                    })

    return {
        'headers': headers,
        'body_text': body_text,
        'body_html': body_html,
        'urls': urls,
        'attachments': attachments,
        'temp_dir': temp_dir,
    }
