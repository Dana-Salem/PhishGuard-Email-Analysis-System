"""
Decision Module
Maps the risk score to a final verdict: ALLOW, QUARANTINE, or BLOCK.
Provides an explanation and recommended actions.
"""


# Thresholds
ALLOW_THRESHOLD = 25      # 0–25  → Allow
QUARANTINE_THRESHOLD = 49 # 26–49 → Quarantine
# 50–100 → Block


def make_decision(score_data):
    """
    Generate a verdict based on the risk score.

    Args:
        score_data: dict from scorer.calculate_score()

    Returns:
        dict with keys: verdict, color, icon, explanation, actions
    """
    score = score_data['score']

    if score <= ALLOW_THRESHOLD:
        return {
            'verdict': 'ALLOW',
            'color': '#22c55e',   # green
            'icon': '✅',
            'risk_level': 'Low Risk',
            'explanation': (
                'This email shows minimal phishing indicators. '
                'The sender appears legitimate, authentication checks passed, '
                'and no high-risk content was detected.'
            ),
            'actions': [
                'Deliver to inbox normally.',
                'No further action required.',
            ],
        }
    elif score <= QUARANTINE_THRESHOLD:
        return {
            'verdict': 'QUARANTINE',
            'color': '#f59e0b',   # amber
            'icon': '⚠️',
            'risk_level': 'Medium Risk',
            'explanation': (
                'This email has several suspicious indicators that suggest '
                'possible phishing. It should be quarantined for manual review '
                'before delivery to the recipient.'
            ),
            'actions': [
                'Move to quarantine folder for admin review.',
                'Do NOT click any links or open attachments.',
                'Verify sender identity through an external channel.',
            ],
        }
    else:
        return {
            'verdict': 'BLOCK',
            'color': '#ef4444',   # red
            'icon': '🚫',
            'risk_level': 'High Risk',
            'explanation': (
                'This email exhibits strong phishing characteristics. '
                'Multiple critical indicators were detected, including '
                'potential spoofing, malicious content, or deceptive URLs. '
                'This email should be blocked immediately.'
            ),
            'actions': [
                'Block delivery — do NOT forward this email.',
                'Report to your security team.',
                'If similar emails are received, investigate a targeted campaign.',
                'Consider blocking the sender domain at the gateway.',
            ],
        }
