"""
Domain Checker Module
Extracts sender domain and runs nslookup + whois analysis.
"""

import subprocess
import re
from datetime import datetime, timezone


TYPOSQUAT_TARGETS = [
    'google', 'microsoft', 'apple', 'amazon', 'paypal', 'netflix',
    'facebook', 'instagram', 'twitter', 'linkedin', 'dropbox', 'yahoo',
    'outlook', 'office365', 'wellsfargo', 'chase', 'bankofamerica',
    'dhl', 'fedex', 'ups', 'usps', 'irs', 'adobe', 'zoom',
]


def _run_cmd(cmd, timeout=15):
    """Run a shell command and return stdout."""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return '[TIMEOUT]'
    except Exception as e:
        return f'[ERROR: {e}]'


def _check_typosquat(domain):
    """Check if domain is a typosquat of a known brand."""
    domain_base = domain.split('.')[0].lower()
    matches = []
    for brand in TYPOSQUAT_TARGETS:
        if brand == domain_base:
            continue  # exact match = legitimate
        # Check edit distance <= 2 or substring match
        if brand in domain_base or domain_base in brand:
            if brand != domain_base:
                matches.append(brand)
                continue
        # Simple Levenshtein approximation
        if abs(len(brand) - len(domain_base)) <= 2:
            diffs = sum(1 for a, b in zip(brand, domain_base) if a != b)
            diffs += abs(len(brand) - len(domain_base))
            if 0 < diffs <= 2 and len(domain_base) > 4:
                matches.append(brand)
    return matches


def _parse_whois_date(date_str):
    """Try to parse a date from whois output."""
    date_formats = [
        '%Y-%m-%dT%H:%M:%SZ',
        '%Y-%m-%d %H:%M:%S',
        '%Y-%m-%d',
        '%d-%b-%Y',
        '%Y/%m/%d',
    ]
    for fmt in date_formats:
        try:
            return datetime.strptime(date_str.strip(), fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def check_domain(headers):
    """Analyze the sender domain using nslookup and whois."""
    findings = []
    flags = {}

    from_email = headers.get('from_email', '')
    if not from_email or '@' not in from_email:
        return {
            'findings': [{'type': 'NO_DOMAIN', 'severity': 'medium',
                          'title': 'No Sender Domain',
                          'detail': 'Could not extract sender domain',
                          'explanation': 'The From address is missing or malformed.'}],
            'flags': {'no_domain': True},
            'domain': '',
            'nslookup_raw': '',
            'whois_raw': '',
        }

    domain = from_email.split('@')[-1]

    # --- nslookup ---
    nslookup_raw = _run_cmd(f'nslookup {domain}')
    flags['dns_resolves'] = 'NXDOMAIN' not in nslookup_raw and 'can\'t find' not in nslookup_raw.lower()

    if not flags['dns_resolves']:
        findings.append({
            'type': 'DNS_NO_RESOLVE', 'severity': 'critical',
            'title': 'Domain Does Not Resolve',
            'detail': f'{domain} returned no DNS records',
            'explanation': 'The sender domain has no DNS records — it may be fake or recently expired.',
        })

    # --- whois ---
    whois_raw = _run_cmd(f'whois {domain}')
    flags['whois_available'] = bool(whois_raw) and 'no match' not in whois_raw.lower()

    # Extract creation date
    creation_date = None
    creation_match = re.search(
        r'(?:creation date|created|registration date|created on)[:\s]+(.+)',
        whois_raw, re.IGNORECASE
    )
    if creation_match:
        creation_date = _parse_whois_date(creation_match.group(1))

    # Extract registrar
    registrar = ''
    registrar_match = re.search(r'registrar[:\s]+(.+)', whois_raw, re.IGNORECASE)
    if registrar_match:
        registrar = registrar_match.group(1).strip()

    # Extract country
    country = ''
    country_match = re.search(r'(?:registrant country|country)[:\s]+(.+)', whois_raw, re.IGNORECASE)
    if country_match:
        country = country_match.group(1).strip()

    # Domain age analysis
    flags['new_domain'] = False
    domain_age_days = None
    if creation_date:
        now = datetime.now(timezone.utc)
        domain_age_days = (now - creation_date).days
        if domain_age_days < 30:
            flags['new_domain'] = True
            findings.append({
                'type': 'NEW_DOMAIN', 'severity': 'high',
                'title': 'Newly Registered Domain',
                'detail': f'{domain} is only {domain_age_days} days old (created {creation_date.strftime("%Y-%m-%d")})',
                'explanation': 'Domains less than 30 days old are frequently used for phishing.',
            })
        elif domain_age_days < 90:
            flags['new_domain'] = True
            findings.append({
                'type': 'YOUNG_DOMAIN', 'severity': 'medium',
                'title': 'Recently Registered Domain',
                'detail': f'{domain} is {domain_age_days} days old',
                'explanation': 'Domains less than 90 days old are sometimes used for phishing.',
            })

    # Typosquatting check
    flags['typosquat'] = False
    typo_matches = _check_typosquat(domain)
    if typo_matches:
        flags['typosquat'] = True
        findings.append({
            'type': 'TYPOSQUAT', 'severity': 'critical',
            'title': 'Possible Typosquatting Domain',
            'detail': f'{domain} resembles: {", ".join(typo_matches)}',
            'explanation': 'The domain closely resembles a well-known brand, which is a common phishing technique.',
        })

    return {
        'findings': findings,
        'flags': flags,
        'domain': domain,
        'domain_age_days': domain_age_days,
        'registrar': registrar,
        'country': country,
        'creation_date': creation_date.isoformat() if creation_date else None,
        'nslookup_raw': nslookup_raw[:2000],
        'whois_raw': whois_raw[:3000],
    }
