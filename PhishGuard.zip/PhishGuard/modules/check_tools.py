"""
PhishGuard Environment Diagnostics
Run this script to verify that all required security tools are installed and in the PATH.
"""

import subprocess
import sys

def check_command(name, command_str):
    print(f"[*] Testing {name}...")
    try:
        # Run the command with help flag
        result = subprocess.run(
            command_str, 
            shell=True, 
            capture_output=True, 
            text=True, 
            timeout=5
        )
        
        # 127 is the standard exit code for "command not found" on Linux
        if result.returncode == 127 or "command not found" in result.stderr.lower():
            print(f"    [FAIL] {name} is NOT INSTALLED or NOT IN PATH.")
            print(f"           Command attempted: {command_str}")
            return False
        elif result.returncode == 0 or len(result.stdout) > 0:
            print(f"    [OK]   {name} is installed and responding correctly.")
            return True
        else:
            print(f"    [WARN] {name} ran, but returned an unexpected error code ({result.returncode}).")
            print(f"           Error Output: {result.stderr.strip()}")
            return False
            
    except Exception as e:
        print(f"    [FAIL] Unexpected error running {name}: {e}")
        return False

def main():
    print("==================================================")
    print("      PhishGuard Tool Diagnostics Checker")
    print("==================================================")
    
    tools = [
        {
            "name": "pdfid", 
            "cmd": "pdfid --help"
        },
        {
            "name": "oleid (via python module)", 
            "cmd": "python3 -m oletools.oleid -h"
        },
        {
            "name": "olevba (via python module)", 
            "cmd": "python3 -m oletools.olevba -h"
        }
    ]
    
    all_passed = True
    for tool in tools:
        if not check_command(tool["name"], tool["cmd"]):
            all_passed = False
    
    print("==================================================")
    if all_passed:
        print("✅ SUCCESS: All tools are properly installed and working!")
        print("   You are ready to run PhishGuard.")
    else:
        print("❌ ERROR: One or more tools failed.")
        print("   Please run: sudo apt install python3-oletools pdfid -y")
        sys.exit(1)

if __name__ == "__main__":
    main()
