"""
Attachment Checker Module
Detects and analyzes PDF, Office docs, ZIPs using PDFiD, oleid, olevba.

"""

import subprocess
import os

DANGEROUS_EXTENSIONS = ['.exe', '.scr', '.bat', '.cmd', '.js', '.vbs', '.ps1',
                        '.wsf', '.msi', '.com', '.pif', '.hta', '.cpl']


def _run_cmd(cmd, timeout=30):
    """Run a shell command and return stdout + stderr."""
    try:
        result = subprocess.run(
            cmd, shell=True, capture_output=True, text=True, timeout=timeout
        )
        if result.returncode == 127 or 'command not found' in result.stderr.lower() or 'not recognized' in result.stderr.lower():
            return '[TOOL_MISSING]', result.stderr.strip()
        return result.stdout.strip(), result.stderr.strip()
    except subprocess.TimeoutExpired:
        return '[TIMEOUT]', ''
    except Exception as e:
        return f'[ERROR: {e}]', ''


def _analyze_pdf(filepath):
    """Run pdfid on a PDF file."""
    findings = []
    stdout, stderr = _run_cmd(f'pdfid "{filepath}"')

    if stdout == '[TOOL_MISSING]':
        findings.append({
            'type': 'TOOL_ERROR', 'severity': 'high',
            'title': 'Missing Tool: pdfid',
            'detail': 'The pdfid command is not installed or not in PATH.',
            'explanation': 'Run: sudo apt install pdfid',
        })
        return {'tool': 'pdfid', 'raw_output': 'Error: Tool missing', 'findings': findings}

    suspicious_keywords = {
        '/JavaScript': 'JavaScript code in PDF',
        '/JS': 'JavaScript code in PDF',
        '/OpenAction': 'Automatic action on open',
        '/AA': 'Additional automatic actions',
        '/Launch': 'Launch external application',
        '/EmbeddedFile': 'Embedded file inside PDF',
        '/AcroForm': 'Interactive form (could be used for credential harvesting)',
        '/RichMedia': 'Embedded rich media (Flash, etc.)',
        '/XFA': 'XML Forms Architecture (can contain scripts)',
    }

    for keyword, description in suspicious_keywords.items():
        # pdfid output format: "/Keyword    count"
        import re
        match = re.search(rf'{re.escape(keyword)}\s+(\d+)', stdout)
        if match and int(match.group(1)) > 0:
            count = int(match.group(1))
            severity = 'critical' if keyword in ('/JavaScript', '/JS', '/Launch') else 'high'
            findings.append({
                'type': 'PDF_SUSPICIOUS', 'severity': severity,
                'title': f'PDF Contains {keyword}',
                'detail': f'{keyword} found {count} time(s)',
                'explanation': description,
            })

    return {'tool': 'pdfid', 'raw_output': stdout[:2000], 'findings': findings}


def _analyze_office(filepath):
    """Run oleid and olevba on Office documents."""
    findings = []

    # oleid
    oleid_out, _ = _run_cmd(f'python3 -m oletools.oleid "{filepath}"')
    if oleid_out == '[TOOL_MISSING]':
        findings.append({
            'type': 'TOOL_ERROR', 'severity': 'high',
            'title': 'Missing Tool: oleid',
            'detail': 'The oleid command is not installed or not in PATH.',
            'explanation': 'Run: sudo apt install python3-oletools',
        })

    if 'VBA Macros' in oleid_out and 'Yes' in oleid_out.split('VBA Macros')[-1][:50]:
        findings.append({
            'type': 'MACRO_DETECTED', 'severity': 'high',
            'title': 'VBA Macros Detected',
            'detail': 'Document contains VBA macros',
            'explanation': 'VBA macros can execute arbitrary code and are commonly used in malware.',
        })

    # olevba
    olevba_out, _ = _run_cmd(f'python3 -m oletools.olevba "{filepath}"')
    if olevba_out == '[TOOL_MISSING]':
        findings.append({
            'type': 'TOOL_ERROR', 'severity': 'high',
            'title': 'Missing Tool: olevba',
            'detail': 'The olevba command is not installed or not in PATH.',
            'explanation': 'Run: sudo apt install python3-oletools',
        })

    suspicious_vba = {
        'AutoExec': ('Auto-execute macro', 'critical'),
        'Auto_Open': ('Auto-open macro', 'critical'),
        'AutoOpen': ('Auto-open macro', 'critical'),
        'Document_Open': ('Document open macro', 'critical'),
        'Shell': ('Shell command execution', 'critical'),
        'PowerShell': ('PowerShell execution', 'critical'),
        'WScript': ('Windows Script Host', 'critical'),
        'CreateObject': ('COM object creation', 'high'),
        'URLDownloadToFile': ('File download from URL', 'critical'),
        'Environ': ('Environment variable access', 'medium'),
        'CallByName': ('Dynamic function call', 'high'),
    }

    for keyword, (desc, severity) in suspicious_vba.items():
        if keyword.lower() in olevba_out.lower():
            findings.append({
                'type': 'VBA_SUSPICIOUS', 'severity': severity,
                'title': f'Suspicious VBA: {keyword}',
                'detail': f'Keyword "{keyword}" found in macro code',
                'explanation': desc,
            })

    return {
        'tool': 'oleid + olevba',
        'oleid_output': oleid_out[:1500],
        'olevba_output': olevba_out[:2000],
        'findings': findings,
    }


def check_attachments(attachments):
    """Analyze email attachments for malicious content."""
    findings = []
    flags = {
        'has_executable': False,
        'has_macro': False,
        'has_pdf_js': False,
        'has_archive': False,
    }
    attachment_results = []

    for att in attachments:
        filename = att['filename']
        filepath = att['filepath']
        _, ext = os.path.splitext(filename.lower())
        size_kb = att['size'] / 1024

        result = {
            'filename': filename,
            'extension': ext,
            'size': f'{size_kb:.1f} KB',
            'content_type': att['content_type'],
            'analysis': None,
            'issues': [],
        }

        # Dangerous executable
        if ext in DANGEROUS_EXTENSIONS:
            flags['has_executable'] = True
            result['issues'].append('Dangerous executable')
            findings.append({
                'type': 'EXECUTABLE_ATTACHMENT', 'severity': 'critical',
                'title': 'Executable Attachment',
                'detail': f'{filename} ({ext})',
                'explanation': f'File extension {ext} is executable and can run malicious code.',
            })

        # PDF analysis
        elif ext == '.pdf':
            analysis = _analyze_pdf(filepath)
            result['analysis'] = analysis
            if analysis['findings']:
                flags['has_pdf_js'] = True
            findings.extend(analysis['findings'])

        # Office document analysis
        elif ext in ('.docx', '.xlsx', '.pptx', '.doc', '.xls', '.ppt', '.docm',
                     '.xlsm', '.pptm'):
            analysis = _analyze_office(filepath)
            result['analysis'] = analysis
            if analysis['findings']:
                flags['has_macro'] = True
            findings.extend(analysis['findings'])

        # Archive files
        elif ext in ('.zip', '.rar', '.7z', '.tar', '.gz'):
            flags['has_archive'] = True
            result['issues'].append('Archive file')
            findings.append({
                'type': 'ARCHIVE_ATTACHMENT', 'severity': 'medium',
                'title': 'Archive Attachment',
                'detail': f'{filename} ({size_kb:.1f} KB)',
                'explanation': 'Archive files can contain hidden executables or malware.',
            })

        attachment_results.append(result)

    return {
        'findings': findings,
        'flags': flags,
        'count': len(attachments),
        'attachment_results': attachment_results,
    }