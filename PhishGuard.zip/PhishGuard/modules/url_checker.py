"""
URL Checker Module
Extracts URLs from email body and analyzes them using curl.
"""

import subprocess
import re
from urllib.parse import urlparse

SHORTENER_DOMAINS = [
    'bit.ly', 'tinyurl.com', 'goo.gl', 't.co', 'ow.ly', 'is.gd',
    'buff.ly', 'adf.ly', 'bl.ink', 'lnkd.in', 'rebrand.ly',
    'tiny.cc', 'shorturl.at', 'cutt.ly', 'rb.gy',
]

SUSPICIOUS_TLDS = [
    '.xyz', '.tk', '.ml', '.ga', '.cf', '.gq', '.top', '.buzz',
    '.club', '.work', '.click', '.link', '.info', '.ru', '.cn',
    '.pw', '.cc', '.ws', '.su', '.biz', '.space',
]


def _run_curl(url, timeout=10):
    """Run curl -I -L to follow redirects and get header info."""
    try:
        result = subprocess.run(
            ['curl', '-I', '-L', '-s', '--max-time', str(timeout),
             '--max-redirs', '10', '-o', '/dev/null', '-w',
             'HTTP_CODE:%{http_code}\nFINAL_URL:%{url_effective}\nREDIRECTS:%{num_redirects}\n',
             url],
            capture_output=True, text=True, timeout=timeout + 5
        )
        output = result.stdout
        http_code = ''
        final_url = ''
        num_redirects = 0

        for line in output.strip().split('\n'):
            if line.startswith('HTTP_CODE:'):
                http_code = line.split(':', 1)[1]
            elif line.startswith('FINAL_URL:'):
                final_url = line.split(':', 1)[1]
            elif line.startswith('REDIRECTS:'):
                try:
                    num_redirects = int(line.split(':', 1)[1])
                except ValueError:
                    num_redirects = 0

        return {
            'http_code': http_code,
            'final_url': final_url,
            'num_redirects': num_redirects,
            'error': None,
        }
    except subprocess.TimeoutExpired:
        return {'http_code': '', 'final_url': '', 'num_redirects': 0, 'error': 'Timeout'}
    except Exception as e:
        return {'http_code': '', 'final_url': '', 'num_redirects': 0, 'error': str(e)}


def check_urls(urls):
    """Analyze a list of URLs for phishing indicators."""
    findings = []
    flags = {
        'has_ip_url': False,
        'has_shortener': False,
        'has_suspicious_tld': False,
        'has_excessive_redirects': False,
        'has_deceptive_subdomain': False,
    }
    url_results = []

    for url in urls[:20]:  # Limit to 20 URLs to avoid long analysis times
        parsed = urlparse(url)
        hostname = parsed.hostname or ''
        result = {
            'url': url,
            'hostname': hostname,
            'issues': [],
            'curl_result': None,
        }

        # IP-based URL
        if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', hostname):
            flags['has_ip_url'] = True
            result['issues'].append('IP-based URL')
            findings.append({
                'type': 'IP_URL', 'severity': 'high',
                'title': 'IP-Based URL Detected',
                'detail': url,
                'explanation': 'URL uses an IP address instead of a domain name — common in phishing.',
            })

        # URL shortener
        if hostname.lower() in SHORTENER_DOMAINS:
            flags['has_shortener'] = True
            result['issues'].append('URL shortener')
            findings.append({
                'type': 'URL_SHORTENER', 'severity': 'medium',
                'title': 'URL Shortener Detected',
                'detail': f'{url} (via {hostname})',
                'explanation': 'URL shorteners hide the real destination, often used in phishing.',
            })

        # Suspicious TLD
        for tld in SUSPICIOUS_TLDS:
            if hostname.lower().endswith(tld):
                flags['has_suspicious_tld'] = True
                result['issues'].append(f'Suspicious TLD ({tld})')
                findings.append({
                    'type': 'SUSPICIOUS_TLD', 'severity': 'medium',
                    'title': 'Suspicious TLD',
                    'detail': f'{hostname} uses {tld}',
                    'explanation': f'The TLD {tld} is frequently abused for phishing domains.',
                })
                break

        # Deceptive subdomain (e.g., login.microsoft.com.evil.xyz)
        brands = ['microsoft', 'google', 'apple', 'paypal', 'amazon', 'netflix', 'facebook']
        parts = hostname.lower().split('.')
        # If there are enough parts to have a subdomain
        if len(parts) > 2:
            # handle cases like .co.uk, .com.au
            tld_offset = 2 if parts[-2] in ['co', 'com', 'org', 'net', 'gov', 'edu'] else 1
            if len(parts) > tld_offset:
                main_domain_parts = parts[-(tld_offset+1):]
                actual_domain = '.'.join(main_domain_parts)
                subdomain_str = '.'.join(parts[:-(tld_offset+1)])
                
                if subdomain_str:
                    for brand in brands:
                        if brand in subdomain_str and brand not in actual_domain:
                            flags['has_deceptive_subdomain'] = True
                            result['issues'].append('Deceptive subdomain')
                            findings.append({
                                'type': 'DECEPTIVE_SUBDOMAIN', 'severity': 'critical',
                                'title': 'Deceptive Subdomain',
                                'detail': f'{hostname} - impersonates {brand} but actual domain is {actual_domain}',
                                'explanation': 'The subdomain impersonates a trusted brand while pointing to a different domain.',
                            })
                            break

        # Phishing Keywords in URL
        phish_keywords = ['login', 'verify', 'update', 'account', 'secure', 'signin', 'auth', 'confirm']
        lower_url = url.lower()
        matched_keywords = [kw for kw in phish_keywords if kw in lower_url and kw not in hostname]
        if len(matched_keywords) > 0:
            result['issues'].append('Phishing keywords in URL')
            findings.append({
                'type': 'PHISHING_URL_KEYWORDS', 'severity': 'medium',
                'title': 'Suspicious URL Keywords',
                'detail': f'Keywords found: {", ".join(matched_keywords)}',
                'explanation': 'URL contains keywords frequently used in phishing attacks to fake authority.',
            })

        # Run curl
        curl_result = _run_curl(url)
        result['curl_result'] = curl_result

        if curl_result['num_redirects'] > 3:
            flags['has_excessive_redirects'] = True
            result['issues'].append(f'{curl_result["num_redirects"]} redirects')
            findings.append({
                'type': 'EXCESSIVE_REDIRECTS', 'severity': 'medium',
                'title': 'Excessive Redirects',
                'detail': f'{url} → {curl_result["num_redirects"]} redirects → {curl_result["final_url"]}',
                'explanation': 'Multiple redirects can hide the real destination.',
            })

        # Check if final URL domain differs from original
        if curl_result['final_url']:
            final_parsed = urlparse(curl_result['final_url'])
            final_host = final_parsed.hostname or ''
            if final_host and hostname and final_host != hostname:
                result['issues'].append(f'Redirects to different domain: {final_host}')

        url_results.append(result)

    return {
        'findings': findings,
        'flags': flags,
        'url_count': len(urls),
        'analyzed': len(url_results),
        'url_results': url_results,
    }
