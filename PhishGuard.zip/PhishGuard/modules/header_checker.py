"""
Header Checker Module
Analyzes email headers for phishing indicators like spoofing, mismatches, and auth failures.
"""

import re

URGENCY_KEYWORDS = [
    'urgent', 'immediate', 'action required', 'verify your account',
    'suspended', 'locked', 'unauthorized', 'expire', 'confirm your',
    'update your', 'click here', 'act now', 'limited time',
    'final warning', 'security alert', 'unusual activity',
    'verify identity', 'reset password', 'account compromised',
]


def check_headers(headers):
    """Analyze email headers for phishing indicators."""
    findings = []
    flags = {}

    from_email = headers.get('from_email', '')
    from_name = headers.get('from_name', '')
    reply_to_email = headers.get('reply_to_email', '')
    return_path_email = headers.get('return_path_email', '')
    subject = headers.get('subject', '')
    auth_results = headers.get('authentication_results', '')
    x_mailer = headers.get('x_mailer', '')

    # From vs Reply-To mismatch
    if reply_to_email and from_email and reply_to_email != from_email:
        from_domain = from_email.split('@')[-1] if '@' in from_email else ''
        reply_domain = reply_to_email.split('@')[-1] if '@' in reply_to_email else ''
        sev = 'critical' if from_domain != reply_domain else 'high'
        flags['from_reply_to_mismatch'] = True
        findings.append({
            'type': 'FROM_REPLY_TO_MISMATCH', 'severity': sev,
            'title': 'From / Reply-To Mismatch',
            'detail': f'From: {from_email} — Reply-To: {reply_to_email}',
            'explanation': 'The Reply-To address differs from the From address. Replies go to a different person.',
        })
    else:
        flags['from_reply_to_mismatch'] = False

    # From vs Return-Path mismatch
    if return_path_email and from_email and return_path_email != from_email:
        flags['from_return_path_mismatch'] = True
        findings.append({
            'type': 'FROM_RETURN_PATH_MISMATCH', 'severity': 'medium',
            'title': 'From / Return-Path Mismatch',
            'detail': f'From: {from_email} — Return-Path: {return_path_email}',
            'explanation': 'The bounce address differs from the sender, possibly sent from a different server.',
        })
    else:
        flags['from_return_path_mismatch'] = False

    # Display Name Spoofing
    flags['display_name_spoofing'] = False
    if from_name:
        email_in_name = re.search(r'[\w.+-]+@[\w-]+\.[\w.]+', from_name)
        if email_in_name:
            spoofed = email_in_name.group().lower()
            if spoofed != from_email:
                flags['display_name_spoofing'] = True
                findings.append({
                    'type': 'DISPLAY_NAME_SPOOFING', 'severity': 'critical',
                    'title': 'Display Name Spoofing Detected',
                    'detail': f'Display name contains "{spoofed}" but actual sender is "{from_email}"',
                    'explanation': 'The display name impersonates a different email address.',
                })

    # SPF
    flags['spf_fail'] = False
    if auth_results:
        m = re.search(r'spf\s*=\s*(pass|fail|softfail|neutral|none)', auth_results, re.I)
        if m and m.group(1).lower() in ('fail', 'softfail'):
            flags['spf_fail'] = True
            findings.append({
                'type': 'SPF_FAIL', 'severity': 'high',
                'title': f'SPF Check Failed ({m.group(1)})',
                'detail': f'SPF result: {m.group(1)}',
                'explanation': 'Sending server is NOT authorized for this domain.',
            })

    # DKIM
    flags['dkim_fail'] = False
    if auth_results:
        m = re.search(r'dkim\s*=\s*(pass|fail|neutral|none)', auth_results, re.I)
        if m and m.group(1).lower() == 'fail':
            flags['dkim_fail'] = True
            findings.append({
                'type': 'DKIM_FAIL', 'severity': 'high',
                'title': 'DKIM Verification Failed',
                'detail': f'DKIM result: {m.group(1)}',
                'explanation': 'Digital signature could not be verified — possible forgery.',
            })

    # DMARC
    flags['dmarc_fail'] = False
    if auth_results:
        m = re.search(r'dmarc\s*=\s*(pass|fail|none)', auth_results, re.I)
        if m and m.group(1).lower() == 'fail':
            flags['dmarc_fail'] = True
            findings.append({
                'type': 'DMARC_FAIL', 'severity': 'high',
                'title': 'DMARC Policy Check Failed',
                'detail': f'DMARC result: {m.group(1)}',
                'explanation': 'Email does not align with domain authentication policy.',
            })

    # Suspicious X-Mailer
    flags['suspicious_mailer'] = False
    if x_mailer:
        for mailer in ['PHPMailer', 'SwiftMailer', 'King Phisher', 'Gophish', 'SET']:
            if mailer.lower() in x_mailer.lower():
                flags['suspicious_mailer'] = True
                findings.append({
                    'type': 'SUSPICIOUS_MAILER', 'severity': 'medium',
                    'title': 'Suspicious Mail Client Detected',
                    'detail': f'X-Mailer: {x_mailer}',
                    'explanation': f'"{x_mailer}" is associated with phishing campaigns.',
                })
                break

    # Urgency keywords
    flags['urgency_keywords'] = False
    subject_lower = subject.lower()
    matched = [kw for kw in URGENCY_KEYWORDS if kw in subject_lower]
    if matched:
        flags['urgency_keywords'] = True
        findings.append({
            'type': 'URGENCY_KEYWORDS', 'severity': 'low',
            'title': 'Urgency Language in Subject',
            'detail': f'Matched: {", ".join(matched)}',
            'explanation': 'Subject uses pressure language common in phishing.',
        })

    # Excessive hops
    flags['suspicious_hops'] = False
    received = headers.get('received', [])
    if len(received) > 8:
        flags['suspicious_hops'] = True
        findings.append({
            'type': 'EXCESSIVE_HOPS', 'severity': 'low',
            'title': 'Excessive Received Hops',
            'detail': f'{len(received)} mail servers',
            'explanation': 'Unusually many mail relays — could indicate anonymous routing.',
        })

    return {
        'findings': findings,
        'flags': flags,
        'summary': {
            'total_findings': len(findings),
            'critical': sum(1 for f in findings if f['severity'] == 'critical'),
            'high': sum(1 for f in findings if f['severity'] == 'high'),
            'medium': sum(1 for f in findings if f['severity'] == 'medium'),
            'low': sum(1 for f in findings if f['severity'] == 'low'),
        }
    }
