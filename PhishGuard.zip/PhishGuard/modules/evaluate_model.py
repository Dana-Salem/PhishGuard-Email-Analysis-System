"""
PhishGuard Evaluation Script
Runs the entire hybrid dataset through the analysis pipeline and calculates metrics.
"""

import os
import csv
import sys
import shutil
from collections import defaultdict
from tqdm import tqdm  # pip install tqdm

from modules.parser import parse_email
from modules.header_checker import check_headers
from modules.domain_checker import check_domain
from modules.url_checker import check_urls
from modules.attachment_checker import check_attachments
from modules.scorer import calculate_score
from modules.decision import make_decision

DATASET_DIR = os.path.join('test_samples', 'hybrid_dataset')
MANIFEST_PATH = os.path.join(DATASET_DIR, 'manifest.csv')


def main():
    if not os.path.exists(MANIFEST_PATH):
        print(f"Error: {MANIFEST_PATH} not found.")
        print("Please run build_hybrid_dataset.py first to generate the dataset.")
        sys.exit(1)

    print("==================================================")
    print("      PhishGuard Automated Evaluation Tool")
    print("==================================================")
    print("Loading manifest...")

    samples = []
    with open(MANIFEST_PATH, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            samples.append(row)

    total_samples = len(samples)
    print(f"Found {total_samples} test cases.")
    print("Starting analysis pipeline (this may take a while)...\n")

    # Metrics
    correct = 0
    confusion_matrix = defaultdict(lambda: defaultdict(int))
    case_stats = defaultdict(lambda: {'total': 0, 'correct': 0})
    
    # Optional: pip install tqdm for progress bar
    try:
        from tqdm import tqdm
        iterator = tqdm(samples, desc="Evaluating", unit="emails")
    except ImportError:
        print("Tip: Install 'tqdm' (pip install tqdm) for a progress bar.")
        iterator = samples

    for row in iterator:
        filename = row['Filename']
        expected = row['Expected'].upper()
        case_id = row['Case']
        filepath = os.path.join(DATASET_DIR, filename)

        if not os.path.exists(filepath):
            continue

        try:
            # 1. Parse
            parsed = parse_email(filepath)
            
            # 2. Analyze
            hr = check_headers(parsed['headers'])
            dr = check_domain(parsed['headers'])
            ur = check_urls(parsed['urls'])
            ar = check_attachments(parsed['attachments'])
            
            # 3. Score & Decide
            score_data = calculate_score(hr, dr, ur, ar)
            decision = make_decision(score_data)
            actual = decision['verdict'].upper()

            # Cleanup temp dir
            if parsed.get('temp_dir'):
                shutil.rmtree(parsed['temp_dir'], ignore_errors=True)

        except Exception as e:
            actual = f"ERROR: {e}"

        # Track metrics
        case_stats[case_id]['total'] += 1
        confusion_matrix[expected][actual] += 1
        
        if actual == expected:
            correct += 1
            case_stats[case_id]['correct'] += 1

    # --- Print Report ---
    print("\n==================================================")
    print("                  EVALUATION REPORT")
    print("==================================================")
    
    accuracy = (correct / total_samples) * 100 if total_samples > 0 else 0
    print(f"Total Evaluated: {total_samples}")
    print(f"Overall Accuracy: {accuracy:.2f}%\n")

    print("--- Confusion Matrix (Expected vs Actual) ---")
    labels = ['ALLOW', 'QUARANTINE', 'BLOCK']
    
    # Header row
    print(f"{'EXPECTED':>12} | " + " | ".join(f"{l:<10}" for l in labels) + " | ERRORS")
    print("-" * 60)
    
    for exp in labels:
        row_str = f"{exp:>12} | "
        errors = sum(v for k, v in confusion_matrix[exp].items() if k not in labels)
        for act in labels:
            val = confusion_matrix[exp][act]
            row_str += f"{val:<10} | "
        row_str += f"{errors:<6}"
        print(row_str)

    print("\n--- Accuracy by Case ---")
    for case_id in sorted(case_stats.keys(), key=lambda x: int(x)):
        stats = case_stats[case_id]
        acc = (stats['correct'] / stats['total']) * 100 if stats['total'] > 0 else 0
        print(f"Case {case_id:>2}: {acc:>6.2f}%  ({stats['correct']}/{stats['total']})")

    print("\n==================================================")
    print("Interpretation Guide:")
    print(" - Expected ALLOW, Actual BLOCK      = False Positive (Annoying for users)")
    print(" - Expected BLOCK, Actual ALLOW      = False Negative (CRITICAL SECURITY FAILURE)")
    print(" - Expected BLOCK, Actual QUARANTINE = Partial Success (Stopped, but not dropped)")
    print("==================================================")


if __name__ == "__main__":
    main()
