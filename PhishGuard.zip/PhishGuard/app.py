"""
Email Phishing Analyzer — Main Application
Flask web server that orchestrates all analysis modules.
"""

import os
import json
import shutil
import tempfile
from datetime import datetime

from flask import Flask, render_template, request, jsonify

from modules.parser import parse_email
from modules.header_checker import check_headers
from modules.domain_checker import check_domain
from modules.url_checker import check_urls
from modules.attachment_checker import check_attachments
from modules.scorer import calculate_score
from modules.decision import make_decision

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 25 * 1024 * 1024  # 25 MB max upload

UPLOAD_DIR = os.path.join(tempfile.gettempdir(), 'phish_analyzer_uploads')
os.makedirs(UPLOAD_DIR, exist_ok=True)


@app.route('/')
def index():
    """Serve the main GUI page."""
    return render_template('index.html')


@app.route('/analyze', methods=['POST'])
def analyze():
    """
    Accept an .eml file upload, run all modules, and return the full report.
    """
    # --- Handle file upload ---
    if 'eml_file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    eml_file = request.files['eml_file']
    if not eml_file.filename:
        return jsonify({'error': 'No file selected'}), 400

    if not eml_file.filename.lower().endswith('.eml'):
        return jsonify({'error': 'Only .eml files are accepted'}), 400

    # Save uploaded file
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    safe_name = f'email_{timestamp}.eml'
    eml_path = os.path.join(UPLOAD_DIR, safe_name)
    eml_file.save(eml_path)

    try:
        # ========================================
        # Pipeline: Parse → Headers → Domain → URLs → Attachments → Score → Decision
        # ========================================

        # Step 1: Parse email
        parsed = parse_email(eml_path)

        # Step 2: Header analysis
        header_results = check_headers(parsed['headers'])

        # Step 3: Domain analysis
        domain_results = check_domain(parsed['headers'])

        # Step 4: URL analysis
        url_results = check_urls(parsed['urls'])

        # Step 5: Attachment analysis
        attachment_results = check_attachments(parsed['attachments'])

        # Step 6: Calculate score
        score_data = calculate_score(
            header_results, domain_results, url_results, attachment_results
        )

        # Step 7: Make decision
        decision = make_decision(score_data)

        # ========================================
        # Build the full report
        # ========================================
        report = {
            'meta': {
                'filename': eml_file.filename,
                'analyzed_at': datetime.now().isoformat(),
                'subject': parsed['headers'].get('subject', ''),
                'from': parsed['headers'].get('from_raw', ''),
                'to': parsed['headers'].get('to', ''),
                'date': parsed['headers'].get('date', ''),
            },
            'score': score_data,
            'decision': decision,
            'headers': header_results,
            'domain': domain_results,
            'urls': url_results,
            'attachments': attachment_results,
            'body_preview': (parsed['body_text'] or '')[:500],
        }

        return jsonify(report)

    except Exception as e:
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500

    finally:
        # Cleanup uploaded file
        try:
            os.remove(eml_path)
        except OSError:
            pass
        # Cleanup temp attachment dir
        if 'parsed' in locals() and parsed.get('temp_dir'):
            try:
                shutil.rmtree(parsed['temp_dir'], ignore_errors=True)
            except Exception:
                pass


if __name__ == '__main__':
    print()
    print('==============================================')
    print('     PhishGuard - Email Phishing Analyzer v1.0')
    print('     http://127.0.0.1:5000')
    print('==============================================')
    print()
    app.run(host='0.0.0.0', port=5000, debug=True)
