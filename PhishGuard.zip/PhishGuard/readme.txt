How to Run the PhishGuard Application


Follow these steps to start the main PhishGuard application. This was built and tested on Kali Linux.


-----------------------------------------------------------------------
Step 1: Install Prerequisites
Open your terminal and run the following commands to install the necessary file-analysis tools:


sudo apt update
sudo apt install dnsutils whois curl pdfid
sudo -H pip3 install -U oletools


-----------------------------------------------------------------------
Step 2: Open the Project Folder
Open your terminal inside the unzipped project folder, or navigate to it using the cd command:


cd path/to/sf_email-phishing-analyzer


-----------------------------------------------------------------------
Step 3: Run the Application
Execute the following Python command to start the main application:

python3 app.py

-----------------------------------------------------------------------
What to Expect:
This command will launch the main PhishGuard system. Depending on your setup, it will initialize the interface (such as starting the local web dashboard), allowing you to upload and test individual .eml files to see the real-time scoring breakdown and the final decision (Allow, Quarantine, or Block).
